// src/app/interfaces/user.ts
export interface UserRequest {
  name: string;
  email: string;
  phone: string;
  password: string;
  role: string;
  status: string;
  agencyId?: number;
  profilePicture?: string;
}

export interface UserResponse {
  id: number;
  profilePicture: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  password:string;
  agencyName?: string;
  agencyId?: number;
  status: string;
  lastLogin?: string;
  createdAt?: string;
  updatedAt?: string;
}
